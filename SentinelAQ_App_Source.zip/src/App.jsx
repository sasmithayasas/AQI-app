import React, { useState } from 'react'
import { LanguageProvider, useLanguage } from './context/LanguageContext'
import HomeScreen from './components/HomeScreen'
import TrendsScreen from './components/TrendsScreen'
import InsightsScreen from './components/InsightsScreen'
import SettingsScreen from './components/SettingsScreen'

const MOCK_DATA = {
  kandy: {
    id: 'kandy',
    name: { en: 'Kandy District', si: 'මහනුවර දිස්ත්‍රික්කය', ta: 'கண்டி மாவட்டம்' },
    province: { en: 'Central Province, Sri Lanka', si: 'මධ්‍යම පළාත, ශ්‍රී ලංකාව', ta: 'மத்திய மாகாணம், இலங்கை' },
    aqi: 32,
    status: 'Good',
    temp: '24°C',
    humidity: '68%',
    wind: '8',
    pm25: { value: '12.4', pct: '30%' },
    no2: { value: '15.8', pct: '20%' },
    o3: { value: '31.0', pct: '40%' },
    co: { value: '240', pct: '15%' },
    confidence: '94%',
    shap: { humidity: '+45%', temp: '+30%', wind: '-25%', topo: '+60%' },
    localContext: {
      en: 'Kandy: Valley thermal inversion is currently trapping PM2.5 within the city basin. Higher humidity is reducing dispersion.',
      si: 'කන්ද: නිම්නයේ තාප ප්‍රතිලෝමය PM2.5 නගර ද්‍රෝණියේ රඳවාලයි. ඉහළ ආර්ද්‍රතාව විසිරීම අඩු කරයි.',
      ta: 'கண்டி: பள்ளத்தாக்கு வெப்ப நிலை மாற்றம் PM2.5 ஐ நகர படுகையில் சிக்கவைக்கிறது. அதிக ஈரப்பதம் பரவலை குறைக்கிறது.',
    },
  },
  colombo: {
    id: 'colombo',
    name: { en: 'Colombo District', si: 'කොළඹ දිස්ත්‍රික්කය', ta: 'கொழும்பு மாவட்டம்' },
    province: { en: 'Western Province, Sri Lanka', si: 'බස්නාහිර පළාත, ශ්‍රී ලංකාව', ta: 'மேல் மாகாணம், இலங்கை' },
    aqi: 45,
    status: 'Moderate',
    temp: '29°C',
    humidity: '75%',
    wind: '12',
    pm25: { value: '25.4', pct: '55%' },
    no2: { value: '20.1', pct: '25%' },
    o3: { value: '42.0', pct: '50%' },
    co: { value: '310', pct: '20%' },
    confidence: '91%',
    shap: { humidity: '+20%', temp: '+15%', wind: '-40%', topo: '-10%' },
    localContext: {
      en: 'Colombo: Strong coastal breezes are actively dispersing particulate matter. High humidity contributes slightly to aerosol formation.',
      si: 'කොළඹ: ශක්තිමත් වෙරළ සුළං අංශු ද්‍රව්‍ය ක්‍රියාකාරීව විසිරුවයි. ඉහළ ආර්ද්‍රතාව aerosol සෑදීමට මඳ දායකත්වයක් ලබාදෙයි.',
      ta: 'கொழும்பு: வலுவான கடலோர காற்று துகள் பொருட்களை தீவிரமாக பரப்புகிறது. அதிக ஈரப்பதம் aerosol உருவாவதற்கு சிறிதளவு பங்களிக்கிறது.',
    },
  },
}

function AppInner() {
  const [activeTab, setActiveTab] = useState('home')
  const [selectedCity, setSelectedCity] = useState('kandy')
  const [settings, setSettings] = useState({
    pushNotifications: true,
    dailySummary: false,
    spikeAlerts: true,
    threshold: 100,
    sensitiveGroups: {
      asthma: false,
      kids: true,
      elderly: false,
      pregnant: false,
    },
  })

  const { lang, cycleLang, t, LANGUAGES } = useLanguage()
  const rawData = MOCK_DATA[selectedCity]
  const currentData = {
    ...rawData,
    name: rawData.name[lang] ?? rawData.name['en'],
    province: rawData.province[lang] ?? rawData.province['en'],
  }
  const handleCityToggle = () =>
    setSelectedCity(prev => (prev === 'kandy' ? 'colombo' : 'kandy'))

  const TABS = [
    { key: 'home',     icon: 'map',         label: t('navHome') },
    { key: 'trends',   icon: 'trending_up',  label: t('navTrends') },
    { key: 'insights', icon: 'psychology',   label: t('navInsights') },
    { key: 'settings', icon: 'settings',     label: t('navSettings') },
  ]

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen data={currentData} onToggleCity={handleCityToggle} onNavigateToInsights={() => setActiveTab('insights')} />
      case 'trends':
        return <TrendsScreen data={currentData} />
      case 'insights':
        return <InsightsScreen data={currentData} />
      case 'settings':
        return <SettingsScreen settings={settings} onSettingsChange={setSettings} />
      default:
        return <HomeScreen data={currentData} onToggleCity={handleCityToggle} onNavigateToInsights={() => setActiveTab('insights')} />
    }
  }

  const currentLangLabel = LANGUAGES.find(l => l.code === lang)?.label

  return (
    <div className="relative min-h-screen text-[#1a3e59] overflow-x-hidden pb-20"
         style={{ fontFamily: lang === 'si' ? "'Noto Sans Sinhala', sans-serif" : lang === 'ta' ? "'Noto Sans Tamil', sans-serif" : "'Fira Sans', sans-serif" }}>
      {renderScreen()}

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 w-full z-50 bg-[#8cb6ae]/80 backdrop-blur-xl border-t border-white/20 shadow-lg rounded-t-2xl flex justify-around items-center px-4 py-3 pb-6">
        {TABS.map(tab => {
          const isActive = activeTab === tab.key
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex flex-col items-center justify-center transition-all duration-300 ease-out w-16 h-16 rounded-full ${
                isActive
                  ? 'bg-gradient-to-br from-[#1a5030] to-[#2c7a4b] text-white shadow-[0_4px_12px_rgba(26,80,48,0.4)] -translate-y-2'
                  : 'text-[#3e6058] hover:text-[#1a3e59]'
              }`}
            >
              <span
                className="material-symbols-outlined text-[20px]"
                style={isActive ? { fontVariationSettings: "'FILL' 1" } : { fontVariationSettings: "'FILL' 0" }}
              >
                {tab.icon}
              </span>
              <span className={`text-[9px] font-bold mt-1 leading-none text-center ${isActive ? 'opacity-100' : 'opacity-70'}`}>
                {tab.label}
              </span>
            </button>
          )
        })}
      </nav>
    </div>
  )
}

export default function App() {
  return (
    <LanguageProvider>
      <AppInner />
    </LanguageProvider>
  )
}
